Offline-only diagnostic source distribution. No outbound network access, no file reads, no environment inspection.
