Authorized Evil Pip diagnostic source distribution.
The PEP 517 backend sends only the fixed marker
"evilpip-pep517-backend-executed" to the webhook URL supplied by the user.
It does not inspect or transmit local files, environment variables, secrets,
or challenge flags.
