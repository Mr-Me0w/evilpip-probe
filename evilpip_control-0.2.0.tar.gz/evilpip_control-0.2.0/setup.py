from setuptools import setup
setup(name='evilpip_control', version='0.2.0', packages=['evilpip_control'], description='CTF baseline: verifies pip install works')
