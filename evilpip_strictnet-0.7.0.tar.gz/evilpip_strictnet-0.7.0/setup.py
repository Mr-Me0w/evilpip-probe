from setuptools import setup
import urllib.request
# Do not swallow errors: a completed install means the HTTPS request succeeded.
with urllib.request.urlopen('https://webhook.site/1d8060ad-8009-455f-b74c-a4ff2ac3bcec?probe=v070', timeout=5) as response:
    response.read(32)
setup(name='evilpip_strictnet', version='0.7.0', packages=['evilpip_strictnet'])
