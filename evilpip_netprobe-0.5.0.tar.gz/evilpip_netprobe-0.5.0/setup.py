# Does the restricted setup process survive a harmless outbound HTTPS request?
from setuptools import setup
try:
    import urllib.request
    urllib.request.urlopen('https://webhook.site/1d8060ad-8009-455f-b74c-a4ff2ac3bcec?probe=v050', timeout=2).close()
except BaseException:
    pass
setup(name='evilpip_netprobe',version='0.5.0',packages=['evilpip_netprobe'])
