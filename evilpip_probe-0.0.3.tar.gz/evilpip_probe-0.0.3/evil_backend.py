"""Offline-only PEP 517 backend; no network or filesystem discovery."""
import base64, csv, hashlib, io, os, zipfile
NAME = "evilpip_probe"
VERSION = "0.0.3"
DIST_INFO = f"{NAME}-{VERSION}.dist-info"

def get_requires_for_build_wheel(config_settings=None):
    return []

def prepare_metadata_for_build_wheel(metadata_directory, config_settings=None):
    target = os.path.join(metadata_directory, DIST_INFO)
    os.makedirs(target, exist_ok=True)
    with open(os.path.join(target, "METADATA"), "w", encoding="utf-8") as f:
        f.write(f"Metadata-Version: 2.1\nName: {NAME}\nVersion: {VERSION}\n\n")
    with open(os.path.join(target, "WHEEL"), "w", encoding="utf-8") as f:
        f.write("Wheel-Version: 1.0\nGenerator: offline-probe\nRoot-Is-Purelib: true\nTag: py3-none-any\n")
    return DIST_INFO

def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    filename = f"{NAME}-{VERSION}-py3-none-any.whl"
    entries = {
        f"{NAME}/__init__.py": '"""Offline sdist diagnostic package."""\n',
        f"{DIST_INFO}/METADATA": f"Metadata-Version: 2.1\nName: {NAME}\nVersion: {VERSION}\n\n",
        f"{DIST_INFO}/WHEEL": "Wheel-Version: 1.0\nGenerator: offline-probe\nRoot-Is-Purelib: true\nTag: py3-none-any\n",
    }
    rows = []
    for path, data in entries.items():
        raw = data.encode()
        digest = base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b"=").decode()
        rows.append((path, "sha256=" + digest, str(len(raw))))
    rows.append((f"{DIST_INFO}/RECORD", "", ""))
    buf = io.StringIO()
    csv.writer(buf, lineterminator="\n").writerows(rows)
    os.makedirs(wheel_directory, exist_ok=True)
    with zipfile.ZipFile(os.path.join(wheel_directory, filename), "w", zipfile.ZIP_DEFLATED) as z:
        for path, data in entries.items():
            z.writestr(path, data)
        z.writestr(f"{DIST_INFO}/RECORD", buf.getvalue())
    return filename
