# Legacy setuptools fallback for pip versions/configurations that use setup.py.
from setuptools import setup
setup(name="evilpip_probe", version="0.0.3", py_modules=["probe"])
