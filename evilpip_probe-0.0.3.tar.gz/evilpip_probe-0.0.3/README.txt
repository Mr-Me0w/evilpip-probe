Harmless dual-mode sdist diagnostic. No network access, file reads, or environment inspection.
